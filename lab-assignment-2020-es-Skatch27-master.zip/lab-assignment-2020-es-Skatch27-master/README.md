# Laboratory assigment

Repository with the files of the laboratory assignment for the course 2020-2021

## Students that will participate in the practice

Student 1: Jordy Ivan San Martin Ponce

Student 2 (optional): Sergio Orejon Perez
