#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include "compute.h"

/* Number of hits */
unsigned int hits;

/* Mutex Semaphore */
pthread_mutex_t mutex;

/* Thread function */
void * thread_function(void * data) {   /* Se mete en el data el numero de puntos a analizar por hilo*/

    /* The input variable contains the number of points that the thread must
     * calculate */
     int points = *((int *)data); 
     unsigned int count =0;   

    double x,y;
    struct drand48_data rand_buffer;
    srand48_r(time(NULL), &rand_buffer); //Guardar semilla
        
    /* TODO: Implement the loop that obtains the random points and counts how
     * many of those lay within the circumference of radius 1 */
   
    for(int i=0; i<points ; i++){
        //Creamos el punto con valores random
        drand48_r(&rand_buffer, &x);
        drand48_r(&rand_buffer, &y);
   
        if((x*x + y*y) <= 1 ){    //Comprueba la distancia del punto al centro para ver si esta dentro
            count++;               //Si esta dentro aumenta el contador
        }  
    }
   
 
    /* TODO: Add the count to the global variable hits in mutual exclusion */
    
    /*Poner aqui el semaforo*/
     //P(MUTEX)
    pthread_mutex_lock(&mutex);
    hits = hits + count;
    printf("Hits actuales: %d\n",hits);
     //V(MUTEX)
    pthread_mutex_unlock(&mutex);
   
    return NULL;

}


void compute(int npoints, int nthreads) {

    /* TODO: Erase the following line: */
   // printf("Se ha inicializado compute(%d, %d)\n", npoints, nthreads);
    
    pthread_t threads[nthreads];  /*Array de identificadores de los hilos que se vayan creando, nos hara falta luego para el join */
    
    
    int nPasar= npoints/nthreads; //Si sale division con decimales redondea hacia abajo siempre
    int np= npoints;    //se vincula (?)
    /*TODO: Initialize the mutex */
    pthread_mutex_init(&mutex, NULL);  
   
    /* TODO: Launch the threads that will count the points */
    for(int i=0; i<nthreads; i++){

        printf("Se van a pasar: %d puntos\n", np); 
     /* TODO: Wait for all threads to finish; es la funcion pthread_join */             
        
        if(i == (nthreads-1)){
            printf("Creando hilo: %d ... \n", i);    
            pthread_create(&(threads[i]), NULL, &thread_function ,  &np);
            pthread_join(threads[i], NULL);   
            
        }else{
            printf("Creando hilo: %d ... \n", i);  
            pthread_create(&(threads[i]), NULL, &thread_function ,  &nPasar);
            pthread_join(threads[i], NULL);   
                  
        }
        np= np - nPasar;
        
    }
    
    printf("El numero total de hits es: %d\n", hits);
   
    /* TODO: print the ratio of points that meet the criteria */

    /* The following print string can be used to print the calculated value:
     * printf("%.8f\n", VALUE_OF_PI);
     * where VALUE_OF_PI is the floating-point value to be printed.
     */
    
   
     float VALUE_OF_PI=((float)hits/(float)npoints)  * 4;
     printf("El valor de PI es: %.8f\n", VALUE_OF_PI);
    
}
