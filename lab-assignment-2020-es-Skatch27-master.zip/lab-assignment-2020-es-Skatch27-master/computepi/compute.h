#ifndef __COMPUTE_H__
#define __COMPUTE_H__

void compute(int npoints, int nthreads);

#endif // __COMPUTE_H__
